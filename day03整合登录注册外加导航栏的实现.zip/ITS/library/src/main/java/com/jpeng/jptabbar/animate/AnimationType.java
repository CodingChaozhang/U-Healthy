package com.jpeng.jptabbar.animate;

/**
 * Created by jpeng on 17-9-4.
 */
public enum AnimationType {
    FLIP,
    ROTATE,
    SCALE,
    JUMP,
    SCALE2,
    NONE,
}
