package com.jpeng.jptabbar;

/**
 * Created by jpeng on 16-11-15.
 * 徽章消失回调监听者
 */
public interface BadgeDismissListener {
    /**
     * TabItem徽章消失的回调
     */
    void onDismiss(int position);
}
